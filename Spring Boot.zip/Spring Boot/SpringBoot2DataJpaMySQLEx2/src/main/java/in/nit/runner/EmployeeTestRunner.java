package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nit.mdodel.Employee;
import in.nit.repo.EmployeeRepository;

@Component
public class EmployeeTestRunner implements CommandLineRunner {
	@Autowired
	private EmployeeRepository repo;
	
	@Override
	public void run(String... args) throws Exception 
	{
		repo.save(new Employee("A", 3.3));
		repo.save(new Employee("B", 4.3));
		repo.save(new Employee("C", 5.3));
	}

}
