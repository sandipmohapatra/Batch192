package in.nit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nit.mdodel.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
/* -------------------------------
1)main() ----with run it it will run the total application
2)employee class -------pojo (hbm)
3)repository--------jpaRepository for save,update(id),delete(id),all,search(id)
4)test the save method();

*/