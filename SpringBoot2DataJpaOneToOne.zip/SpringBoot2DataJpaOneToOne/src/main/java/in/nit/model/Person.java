package in.nit.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
public class Person {
	@Id
	@NonNull
	
	private Integer perId;
	public Person() {
		super();
	}

	public Person(@NonNull Integer perId, String perName, String perGender, String perAddr, PanCard card) {
		super();
		this.perId = perId;
		this.perName = perName;
		this.perGender = perGender;
		this.perAddr = perAddr;
		this.card = card;
	}

	public Integer getPerId() {
		return perId;
	}

	public void setPerId(Integer perId) {
		this.perId = perId;
	}

	public String getPerName() {
		return perName;
	}

	public void setPerName(String perName) {
		this.perName = perName;
	}

	public String getPerGender() {
		return perGender;
	}

	public void setPerGender(String perGender) {
		this.perGender = perGender;
	}

	public String getPerAddr() {
		return perAddr;
	}

	public void setPerAddr(String perAddr) {
		this.perAddr = perAddr;
	}

	public PanCard getCard() {
		return card;
	}

	public void setCard(PanCard card) {
		this.card = card;
	}

	private String perName;
	private String perGender;
	private String perAddr;
	
	@ManyToOne //1...1
	@JoinColumn(
			name="cardIdFk",
			unique = true
			)
	private PanCard card;
	
}
