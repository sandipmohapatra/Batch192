import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Registration")
public class Registration extends HttpServlet 
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	res.setContentType("text/html");
	PrintWriter out=res.getWriter();
	String name=req.getParameter("name");
	String phone=req.getParameter("phone");
	String email=req.getParameter("email");
	String pass=req.getParameter("pass");
	String address=req.getParameter("address");
	out.println("the name is "+name);
	out.println("the phone is "+phone);
	out.println("the email is "+email);
	out.println("the pass is "+pass);
	out.println("the address is "+address);
	
}
}