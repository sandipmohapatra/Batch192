let password:string = " john ";
if(password.trim()=="john"){
    console.log('Verified..');
} else {
    console.log('Invalid Password');
}
