let product = new Map([
    [1, "Samsung TV"],
    [2, "Nike Causuals"]
]);
console.log(product.get(1));       
console.log(product.size); 
console.log(product.delete(1));
console.log(product.has(3));   
console.log(product);      
