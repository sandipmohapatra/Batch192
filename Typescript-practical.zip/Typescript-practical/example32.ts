let values:number[] = [10, 20, 30,40];
let [a,b,c,d] = values;
console.log(`A=${a}\nB=${b}\nC=${c}\nD=${d}`);
