function PrintValue(param) {
    return param;
}
console.log(PrintValue("String Value"));
console.log(PrintValue(10));
