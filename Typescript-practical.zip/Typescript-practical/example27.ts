let products:string[] = ["TV","Mobile","Shoe"];
console.log(`To String: ${products.toString()}`);
console.log(`Join : ${products.join("-->")}`);
console.log(`Slice : ${products.slice(1,2)}`);
