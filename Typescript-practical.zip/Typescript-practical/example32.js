var values = [10, 20, 30, 40];
var a = values[0], b = values[1], c = values[2], d = values[3];
console.log("A=" + a + "\nB=" + b + "\nC=" + c + "\nD=" + d);
