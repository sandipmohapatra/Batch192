var msg = "Welcome to JavaScript String Methods.";
if (msg.includes("TypeScript")) {
    console.log("You are using TypeScript");
}
else if (msg.includes("JavaScript")) {
    console.log("You are using JavaScript");
}
