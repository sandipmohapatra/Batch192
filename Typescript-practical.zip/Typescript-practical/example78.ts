enum Play 
{
    Last,			// valid - 0
    Next = "Next Song",
    Prev = "Previous Song",
    First = "First Song"
}
console.log(`Last Value ${Play.Last}`);
console.log(`Prev : ${Play.Prev}`);

